// module/wifi/web/static/js/config.js

let lang_global;
let animation = false;

const unsafeProtocols = ["WEP", "WPA", "HTTP", "FTP", "Telnet", "RDP", "SNMP", "ICMP"];

let mas_sonar = [
    ['wifi_0jdccc', 'wifi_0jdccc1']
];

// schedule
let main_color = "#68ff9d";
let text_color = "#ffffffd4";
