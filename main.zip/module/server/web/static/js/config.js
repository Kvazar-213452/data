// module/server/web/static/js/config.js

let lang_global;

let mas_sonar = [
    ['server_0jdccc']
];
