// module/cleaning/web/static/js/config.js

let lang_global;
let animation = false;

let mas_sonar = [
    ['wifi_0jdccc', 'wifi_0jdccc1']
];

let data_cleaning = {
    backup: 0,
    wifi: 0,
    desktop: 0,
    doskey: 0
};

// cleanup
let bg_color1 = "rgb(24, 24, 34)";
let bg_color2 = "rgb(89, 89, 89)";
