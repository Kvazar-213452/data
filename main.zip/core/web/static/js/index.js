// core\web\static\js\index.js

function page_iframe(name, btn) {
    $.ajax({
        url: "/api/get_file",
        type: "POST",
        contentType: "application/json",
        data: JSON.stringify({data: `../module/${name}/starter.md`}),
        success: function (response) {
            $("#iframe").attr("src", response["val"]);

            button_hover(btn);
        }
    });
}

$(document).ready(function() {
    fetchLogs();
});

function get_status_reg() {
    $.ajax({
        url: "/api/get_json_file",
        type: "POST",
        contentType: "application/json",
        data: JSON.stringify({data: "data/user.json"}),
        success: function (response) {
            let reg_login = response["val"]["acsses"];

            if (reg_login == 1) {
                $("#btn11").hide();
            }
        }
    });
}

function get_module() {
    $.ajax({
        url: "/api/get_json_file",
        type: "POST",
        contentType: "application/json",
        data: JSON.stringify({data: "data/config_module.json"}),
        success: function (response) {
            render_module(response);
        }
    });
}

function render_module(response) {
    let total = response["val"]["module_uinstall"].length;
    let completed = 0;

    for (let i = 0; i < total; i++) {
        let name = response["val"]["module_uinstall"][i];

        $.ajax({
            url: "/api/get_module_for_render",
            type: "POST",
            contentType: "application/json",
            data: JSON.stringify({data: name}),
            success: function (response) {
                let text = `
                    <div onclick="page_iframe('${name}', 'btn${i}')" id="btn${i}" class="button">
                    <img src="data:image/png;base64,${response["icon"]}"><p></p>
                    </div>
                `;
                $(".menu_div").prepend(text);

                db_lang.push([`btn${i}`, response["data"]["lang"]]);
                completed++;

                if (completed === total) {
                    $.ajax({
                        url: "/api/get_json_file",
                        type: "POST",
                        contentType: "application/json",
                        data: JSON.stringify({data: "data/config.json"}),
                        success: function (response) {
                            let type = response["val"]["lang"];

                            $("#relon p").html(lang_db[type]["relon"]);
                            $("#btn12 p").html(lang_db[type]["btn12"]);
                            $("#btn11 p").html(lang_db[type]["btn11"]);

                            for (let i = 0; i < db_lang.length; i++) {
                                $(`#${db_lang[i][0]} p`).html(db_lang[i][1][type]);
                            }

                            module_integrated("settings", "btn12");
                        }
                    });
                }
            }
        });
    }
}

$(window).on("message", function(event) {
    const receivedData = event.originalEvent.data;

    if (receivedData === "lang_change") {
        change_lang_now(1);
    } else if (receivedData === "reload") {
        location.reload();
    }
});

function fetchLogs() {
    $.ajax({
        url: "/api/get_file",
        type: "POST",
        contentType: "application/json",
        data: JSON.stringify({data: "data/main.log"}),
        success: function (response) {
            const logsArray = response["val"].split('\n');

            $('.console').html(logsArray.join('<br>'));
        }
    });
}

function console_open() {
    fetchLogs();
    $('.console').toggle();
}

$(document).on('keydown', function(event) {
    if (event.key === ']' || event.key === 'ї') {
        console_open();
    }
});

function render_main_start() {
    $('.ump_textw').html(html_1);

    get_module();
    get_status_reg();
}

function module_integrated(name, btn) {
    $.ajax({
        url: "/api/get_file",
        type: "POST",
        contentType: "application/json",
        data: JSON.stringify({data: `des/starter.md`}),
        success: function (response) {
            $("#iframe").attr("src", response["val"] + name);

            button_hover(btn);
        }
    });
}
