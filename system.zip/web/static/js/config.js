// module/system/web/static/js/config.js

let lang_global;

let mas_sonar = [
    ['system_0jdccc', 'system_0jdccc1']
];
