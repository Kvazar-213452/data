// app_front_end/static/js/config.js

let visualization_mas = ['visualization1', 'visualization2'];
let vsgretdbgc = ['vsgretdbgc1', 'vsgretdbgc2'];
let shell_NM = ['shell_NM', 'shell_NM1', 'shell_NM2'];
let frg45th9nd = ['frg45th9nd', 'frg45th9nd1', 'frg45th9nd2'];
let setingss_vdwewe = ['setingss_vdwewe', 'setingss_vdwewe1'];
let vvw2311323ferererg3g3g3 = ['vvw2311323ferererg3g3g3', 'vvw2311323ferererg3g3g31'];

let mas_sonar = [
    ['dwdc21e12d', 'dwdc21e12d1', 'dwdc21e12d2', 'dwdc21e12d3', 'dwdc21e12d4']
];

let antivirus_flash_drive;
let lang_global;
let data_json_exe;
let scan_virus_file;
