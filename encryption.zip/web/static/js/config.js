// module/encryption/web/static/js/config.js

let frg45th9nd = ['frg45th9nd', 'frg45th9nd1', 'frg45th9nd2'];

let mas_sonar = [
    ['dwdc21e12dq', 'dwdc21e12dq1']
];

let lang_global;
let type;
let type_dec;
let algoritm = 5;
